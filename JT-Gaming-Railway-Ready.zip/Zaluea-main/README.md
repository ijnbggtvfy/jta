# J.T Gaming

A futuristic gaming dashboard built as a small Node.js web app.

## Run locally

```bash
npm install
npm start
```

Open http://localhost:8080

## Railway

Deploy the repository as a Node service. Railway can use the included `railway.json` and `npm start` command. The server listens on Railway's `PORT` environment variable and exposes `/api/health` for health checks.
