var updatesList = [
    {message: "J.T Gaming dashboard online."},
    {message: "New futuristic homepage interface installed."}
];
var updatespage = document.getElementById("updatespage");
if(updatespage){
  updatesList.forEach(function(item){
    var row=document.createElement("div");
    row.className="message";
    row.textContent=item.message;
    updatespage.appendChild(row);
  });
}
