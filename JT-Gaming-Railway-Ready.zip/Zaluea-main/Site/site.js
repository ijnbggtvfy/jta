function settings() {
    const el=document.getElementById("settings");
    if(el) el.classList.toggle("open");
}
function updates() {
    const el=document.getElementById("updates");
    if(el) el.classList.toggle("open");
}
const savedTitle=localStorage.getItem("title");
if(savedTitle) document.title=savedTitle;
function titleSet(text) {
    if(text.trim()){document.title=text;localStorage.setItem("title",text);}
    else {localStorage.removeItem("title");document.title="J.T | Gaming";}
}
function iconSet(url){
    if(!url.trim()) return;
    let icon=document.querySelector("link[rel='icon']");
    if(icon) icon.href=url;
}
function reset(){
    localStorage.removeItem("title");
    localStorage.removeItem("icon");
    location.reload();
}
