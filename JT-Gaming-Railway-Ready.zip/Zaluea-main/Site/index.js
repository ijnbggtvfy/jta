const form = document.querySelector('#search');
const input = document.querySelector('#searchInput');

if (form && input) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const value = input.value.trim();
    if (!value) return;

    const url = /^(https?:\/\/)/i.test(value)
      ? value
      : `https://www.google.com/search?q=${encodeURIComponent(value)}`;

    window.open(url, '_blank', 'noopener,noreferrer');
  });
}

function quickLink(url) {
  window.open(url, '_blank', 'noopener,noreferrer');
}

function askAI() {
  const box = document.getElementById('command');
  const q = box?.value.trim();
  if (!q) return;
  alert(`J.T AI\n\nCommand received:\n${q}\n\nYour dashboard is live. Connect this panel to your own AI API when you're ready.`);
  box.value = '';
}

function fillCommand(text) {
  const box = document.getElementById('command');
  if (box) { box.value = text; box.focus(); }
}
